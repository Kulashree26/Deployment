from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re 

app = Flask(__name__)

app.secret_key = 'abc'

app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']='260399'
app.config['MYSQL_DB']='Internshiptask'

mysql = MySQL(app)

@app.route('/')

@app.route('/login' , methods = ['GET', 'POST'])
def login():
    msg=''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s AND password = %s', (username, password, ))
        account = cursor.fetchone()
        if account:
            session['loggedin'] = True
            session['username'] = account['username']
            session['password'] = account['password']
            msg = 'Logged in successfully!'
            return msg
        else:
            msg = 'Incorrect username password!'
    return render_template('login.html', msg=msg)


@app.route('/register', methods=['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'mail' in request.form:
        username = request.form['username']
        password = request.form['password']
        email = request.form['mail']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address!'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers!'
        elif not username or not password or not email:
            msg = 'Please fill out the form!'
        else:
            cursor.execute('INSERT INTO accounts VALUES (%s, %s, %s)', (username, password, email))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
            return msg
    elif request.method == 'POST':
        msg = 'Please fill out the form!'
    return render_template('register.html', msg=msg)
    #return "<h3> hi {} </br> your email id is {} </h3> </br> <h1> {} </h1>".format(username, email, msg)

@app.route('/recover', methods = ['GET', 'POST'])
def recover():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'email' in request.form :
        username = request.form['username']
        email = request.form['email']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s AND email = % s',(username, email))
        account = cursor.fetchone()
        if account:
            session['username'] = account['username']
            session['email'] = account['email']
            cursor.execute('SELECT Password FROM accounts WHERE username = % s AND email = % s',(username, email))
            password = cursor.fetchone()['Password']
            msg = 'Your password is ' + password
            return render_template('login.html', msg = msg)
        else :
            msg = 'Incorrect username / e-mail !'
    return render_template('recover.html', msg = msg)

if __name__=="__main__":
    app.run(debug=True)