from flask import Flask , redirect, request, render_template
import pickle
import numpy as np

app=Flask(__name__)

@app.route("/")
def fun1():
    return render_template("Sal_pred.html")

@app.route("/predict", methods=["post"])
def fun2():
    nm=request.form['name']
    exp=float(request.form['experience'])
    mymodel = pickle.load(open('salary_model.pkl', "rb"))
    sal = round(mymodel.predict([[exp]])[0],2)
    return "hi {} your prediction salary is {}".format(nm,sal)

if __name__=="__main__":
    app.run(debug=True)