from flask import Flask, redirect, request, render_template
import pickle
import numpy as np
import pandas as pd

car_price=Flask(__name__)

@car_price.route("/")
def fun1():
    return render_template("car_price.html")

@car_price.route("/predict", methods=["post"])
def fun2():
    car_nm=request.form['car_name']
    yr = int(request.form['year'])
    Pp = float(request.form['Present_price'])
    kms = int(request.form['kms_driven'])
    FT = request.form['Fuel_Type']
    ST = request.form['Seller_Type']
    Trans = request.form['Transmission']
    Owner = int(request.form['Owner'])
    mymodel = pickle.load(open('car_price.pkl', "rb"))

    values = [[car_nm, yr, Pp, kms, FT, ST, Trans, Owner]]
    df = pd.DataFrame(data=values, columns=['Car_Name', 'Year', 'Present_Price', 'Kms_Driven', 'Fuel_Type', 'Seller_Type', 'Transmission', 'Owner'])

    SP = round(mymodel.predict(df)[0], 2)
    return "<b>Predicted selling price of {} is {} lacs.</b>".format(car_nm, SP)


if __name__=='__main__':
    car_price.run(debug=True)