from flask import Flask, redirect,request, render_template
import pickle
import numpy as np

Titanic=Flask(__name__)

@Titanic.route("/")
def fun1():
    return render_template("Titanic_input.html")


@Titanic.route("/predict" , methods=["post"])
def fun2():
    Pass_Id=request.form['PassengerId']
    Pclass=request.form['PClass']
    nm=request.form['name']
    sex=int(request.form['sex'])
    age=request.form['age']
    SibSp=request.form['sibsp']
    parch=request.form['parch']
    fare=request.form['fare']
    emb=request.form['Embarked']
    mymodel=pickle.load(open('titanic_model.pkl', 'rb'))
    surv=mymodel.predict([[Pass_Id,Pclass,sex,age,SibSp,parch,fare,emb]])[0]

    if surv == 0:
        out = "Not Survived"
    else:
        out = "Survived"

    return "{} has {}".format(nm,out)

if __name__ == "__main__":
    Titanic.run(debug=True)